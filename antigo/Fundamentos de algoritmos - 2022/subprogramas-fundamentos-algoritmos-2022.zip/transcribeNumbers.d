transcribeNumbers.o transcribeNumbers.d : transcribeNumbers.c
