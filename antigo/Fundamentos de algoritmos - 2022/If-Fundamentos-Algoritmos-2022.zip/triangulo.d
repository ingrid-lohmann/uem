triangulo.o triangulo.d : triangulo.c
