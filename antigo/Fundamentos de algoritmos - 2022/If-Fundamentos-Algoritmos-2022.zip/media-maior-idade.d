media-maior-idade.o media-maior-idade.d : media-maior-idade.c
