from GoogleNews import GoogleNews
from newspaper import Article, Config
import pandas as pd
import dateparser
import time
import re

# Configuração de "Disfarce"
config_navegador = Config()
config_navegador.browser_user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
config_navegador.request_timeout = 10

def limpar_url_google(url_suja):
    url_limpa = re.sub(r'&ved=.*', '', url_suja)
    url_limpa = re.sub(r'&usg=.*', '', url_limpa)
    return url_limpa

def validar_relevancia(titulo, texto, evento):
    """
    O Porteiro Rigoroso 3.0: Exige que a relevância esteja na Manchete.
    """
    titulo_lower = titulo.lower()

    # Termos Obrigatórios (Whitelist) por Evento - USADOS PARA VETAR OUTROS ASSUNTOS
    termos_juridicos = ['acordo', 'reparação', 'indenização', 'justiça', 'homologação', 'repactuação', 'mpf', 'multa']

    if 'Mariana' in evento:
        obrigatorios_titulo = ['mariana', 'samarco', 'fundão', 'rio doce', 'bacia do rio doce'] + termos_juridicos
    elif 'Brumadinho' in evento:
        obrigatorios_titulo = ['brumadinho', 'córrego do feijão', 'paraopeba'] + termos_juridicos
    else:
        obrigatorios_titulo = ['vale'] # Fallback

    # 1. TESTE PRINCIPAL (DITADURA DO TÍTULO)
    # A notícia é aprovada se o TÍTULO contiver pelo menos um termo obrigatório OU "Vale" + um termo jurídico

    tem_termo_especifico = any(t in titulo_lower for t in obrigatorios_titulo)
    tem_vale_no_titulo = 'vale' in titulo_lower or 'vale3' in titulo_lower

    if not (tem_termo_especifico or tem_vale_no_titulo):
        return False, "Sem menção específica no título (Ruído de mercado)"

    # Se o título tem termos de desastre (OK), verificamos o corpo do texto para evitar notícias muito curtas

    # 2. TESTE DE CONTEÚDO MINIMO (Só para garantir)
    conteudo_completo = (titulo_lower + " " + texto.lower())
    if 'oi' in titulo_lower and 'mariana' not in titulo_lower:
        return False, "Regra de exclusão: Título sobre Oi/OIBR3"

    # Se a notícia passou pela regra do título (tem o assunto principal), a mantemos.
    return True, "Aprovado"

def buscar_com_filtro_definitivo():
    janelas = [
        # 1. Mariana (2015)
        {'inicio': '10/25/2015', 'fim': '11/30/2015', 'termo_base': 'Vale barragem Mariana', 'evento': 'Mariana_2015'},
        # 2. Brumadinho (2019)
        {'inicio': '01/20/2019', 'fim': '02/20/2019', 'termo_base': 'Vale barragem Brumadinho', 'evento': 'Brumadinho_2019'},
        # 3. Acordo Brumadinho (2021)
        {'inicio': '01/25/2021', 'fim': '02/15/2021', 'termo_base': 'Vale acordo Brumadinho', 'evento': 'Acordo_Brumadinho_2021'},
        # 4. Acordo Mariana (2024)
        {'inicio': '10/15/2024', 'fim': '11/15/2024', 'termo_base': 'Vale acordo Mariana repactuação', 'evento': 'Acordo_Mariana_2024'}
    ]

    todas_noticias = []
    urls_ja_vistas = set()

    print("=== Iniciando Coleta Definitiva (Apenas Manchetes Válidas) ===")

    for janela in janelas:
        print(f"\n>>> Fase: {janela['evento']}")

        # Query composta
        sites_financeiros = "site:infomoney.com.br OR site:moneytimes.com.br OR site:braziljournal.com OR site:suno.com.br"
        query_combinada = f"{janela['termo_base']} OR ({janela['termo_base']} ({sites_financeiros}))"

        gnews = GoogleNews(lang='pt', region='BR', start=janela['inicio'], end=janela['fim'])
        gnews.search(query_combinada)

        for p in range(1, 4):
            gnews.get_page(p)
            time.sleep(1)

        resultados = gnews.results()
        print(f"   Links brutos encontrados: {len(resultados)}")

        aprovadas_fase = 0
        meta_fase = 5

        for item in resultados:
            if aprovadas_fase >= meta_fase: break

            url = limpar_url_google(item['link'])
            if url in urls_ja_vistas: continue

            conteudo = processar_noticia(url)

            if conteudo:
                # O filtro precisa do título e do texto.
                aprovado, motivo = validar_relevancia(conteudo['titulo'], conteudo['texto'], janela['evento'])

                if aprovado:
                    urls_ja_vistas.add(url)
                    if not conteudo['data']: conteudo['data'] = item.get('date')

                    conteudo['evento_fase'] = janela['evento']
                    todas_noticias.append(conteudo)
                    aprovadas_fase += 1
                    print(f"   ✅ [Salvo]: {conteudo['titulo'][:40]}...")
                # else: print(f"   🚫 [Rejeitado - {motivo}]: {conteudo['titulo'][:30]}...") # Debug

        gnews.clear()
        time.sleep(2)

    return todas_noticias

def processar_noticia(url):
    try:
        article = Article(url, config=config_navegador)
        article.download()
        article.parse()
        if len(article.text) < 200: return None
        data_str = article.publish_date.strftime('%Y-%m-%d') if article.publish_date else None
        return {"titulo": article.title, "texto": article.text, "url": url, "data": data_str}
    except:
        return None

if __name__ == "__main__":
    dados = buscar_com_filtro_definitivo()
    if dados:
        df = pd.DataFrame(dados)
        df['data'] = pd.to_datetime(df['data'], errors='coerce').dt.strftime('%Y-%m-%d')
        df = df.dropna(subset=['data'])
        df.to_csv("noticias_vale_definitivo.csv", index=False)
        print(f"\n🎉 Sucesso! {len(df)} notícias definitivas salvas.")
        print("\n--- Etapa 1 Concluída! Base de Dados Pronta para o Preço. ---")
    else:
        print("\nNenhuma notícia passou no filtro. Tente mudar o termo de busca.")